
Value Calculator — 30‑second deploy

1) Go to glitch.com → New Project → Hello‑Webpage.
2) In the Glitch editor, delete the default files.
3) Click “Upload” → drag EVERY file from this folder (index.html, manifest.json, sw.js, icons).
4) Click “Preview” → “Preview in a new window”. Copy that URL.
5) On your iPhone open the URL in Safari → Share → Add to Home Screen.

Done. The app will open full‑screen and work offline.
