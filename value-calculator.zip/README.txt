
Value Calculator — ready for GitHub Pages or any static host

Files:
- index.html  (the app)
- manifest.json  (PWA metadata)
- sw.js  (offline support)
- icon-192.png, icon-512.png  (app icons)

Deploy to GitHub Pages:
1) Create a public repo named value-calculator.
2) Upload all these files.
3) Settings → Pages → Source: Deploy from a branch → Branch: main → Save.
4) Open https://YOURNAME.github.io/value-calculator and Add to Home Screen in Safari.

Local test on iPhone without hosting:
- Install “Web Server for iOS” → choose this folder → Start → open the localhost link in Safari → Add to Home Screen.
